<?php
// Obtener la info
require "fn/producto.inc.php";
$productos = producto\obtenerArray();
//var_dump($productos);exit;
//--------------------------------------
// Responder el excel
require 'lib/phpexcel/PHPExcel.php';
$objPHPExcel = new PHPExcel();
$objPHPExcel->getProperties()
->setCreator("Roberto")
->setLastModifiedBy("Roberto")
->setTitle("Documento Excel de Prueba")
->setSubject("Documento Excel de Prueba")
->setDescription("Demostracion sobre como crear archivos de Excel desde PHP.")
->setKeywords("Excel Office 2013 openxml php")
->setCategory("Pruebas de Excel");
//titulos
$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue('A1', 'Categoria')
            ->setCellValue('B1', 'Nombre')
            ->setCellValue('C1', 'Precio')
            ->setCellValue('D1', 'Marca');
// estilos
$styleArray = array(
    'font' => array(
        'bold' => true,
        'color' => array('rgb' => 'FFFFFF'),
    ),
    'fill' => array(
        'type' => PHPExcel_Style_Fill::FILL_SOLID,
        'color' => array('rgb' => '435E8B')
    )
);
$objPHPExcel->getActiveSheet() 
            ->getStyle('A1:D1')
            ->applyFromArray($styleArray);
// informacion en celdas
$cant = count($productos);
for($i=0;$i<$cant;$i++){
    $fila = $i + 2;
    $objPHPExcel->setActiveSheetIndex(0)
                ->setCellValue('A'.$fila, $productos[$i]["CATEGORIA"])
                ->setCellValue('B'.$fila, $productos[$i]["NOMBRE"])
                ->setCellValue('C'.$fila, $productos[$i]["PRECIO"])
                ->setCellValue('D'.$fila, $productos[$i]["MARCA"]);
}
// Ajustar columnas
foreach(range("A","D") as $columnID) {
    $objPHPExcel->getActiveSheet()
                ->getColumnDimension($columnID) 
                ->setAutoSize(true);
}
/*
function ajustarColumnas($ini, $fin){
    foreach(range($ini, $fin) as $columnID) {
        $objPHPExcel->getActiveSheet()
                    ->getColumnDimension($columnID) 
                    ->setAutoSize(true);
    }
}
genExcel\ajustarColumnas("A", "D");
*/

// RESPUESTA DEL SERVIDOR
$fecha = date("Ymdhis");
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="'.$fecha.'_Planificaciones.xlsx"'); // para setear el nombre del archivo.
header('Cache-Control: max-age=0');
$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007'); 
$objWriter->save('php://output');
