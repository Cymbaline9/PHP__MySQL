<?php
	require "fn/template.inc.php";	
	require "fn/combo.inc.php";
	require "fn/producto.inc.php";

	if($_SERVER["REQUEST_METHOD"]=="POST"){		
		require "fn/upload.inc.php";

		// Captura de datos
		$id = $_POST["id"];
		$nombre = $_POST["nombre"];
		$categoria = $_POST["categoria"];
		$precio = $_POST["precio"];
		$marca = $_POST["marca"];
		$foto = $_FILES["fotografia"];
		
		// VALIDACION AQUI... 
		$rutaFoto = upload\subirArchivo($foto);

		if($id){
			// Si hay una foto nueva
			if($rutaFoto){
				// obtener la ruta de la foto anterior
				$prod = producto\obtenerPorId($id);
				// si habia foto anterior, borrar la foto 
				if($prod["foto"]){
					unlink($prod["foto"]);
				}
			}
			
			// Modificar el producto	
			producto\modificar($id, $nombre, $categoria, $precio, $marca, $rutaFoto);
			$id_nuevo = $id;
		}
		else{
			//Creacion del producto en Base de Datos			
			$id_nuevo = producto\crear($nombre, $categoria, $precio, $marca, $rutaFoto);
		}
		
		if($id_nuevo){
			header("Location: producto.php?id=$id_nuevo");
		}	
	}	
	else{ // Entro al formulario por primera vez

		if(isset($_GET["id"])){
			// Edicion
			$prod = producto\obtenerPorId($_GET["id"]);
			$id = $prod["id_producto"];
			$nombre = $prod["nombre"];
			$precio = $prod["precio"];
			$cod_marca = $prod["cod_marca"];
			$cod_cat = $prod["cod_categoria"];
			$foto_anterior = $prod["foto"];
		}
		else{
			// Alta
			$id = "";
			$nombre = "";
			$precio = "";
			$cod_marca = NULL;
			$cod_cat = NULL;
			$foto_anterior = "";
		}
	}
	//---------------------------------------
	$dic = array(
		"{{ENCABEZADO}}" => template\encabezado(),
		"{{PIE}}" => template\pie(),
		"{{OPTIONS_CATEGORIAS}}" => combo\categorias($cod_cat),
		"{{OPTIONS_MARCAS}}" => combo\marcas($cod_marca),
		"{{NOMBRE}}" => $nombre,
		"{{PRECIO}}" => $precio,
		"{{ID}}" => $id,
		"{{FOTO_ANTERIOR}}" => $foto_anterior,
	);
	echo template\render("templates/formulario.html", $dic);