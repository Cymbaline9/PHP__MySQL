<?php
require "fn/template.inc.php";
require "fn/validacion.inc.php";

//---------------------------------------------------
if($_SERVER["REQUEST_METHOD"] == "POST"){ // procesar el formulario
	$nombre = $_POST["nombre"];
	$apellido = $_POST["apellido"];
	$email = $_POST["email"];
	$clave = $_POST["pass"];
	$clave2 = $_POST["pass2"];	
	$terminos = isset($_POST["terminos"]);
	$checked = ($terminos)? "checked" : "";

	//var_dump($_POST);

	$errores = "";
	$form_valido = true;

	if(!validacion\nombre($nombre)){
		$form_valido = false;
		$errores .= '<p style="color:red">Nombre debe tener x caracteres</p>';
	}

	if(!validacion\nombre($apellido)){
		$form_valido = false;
		$errores .= '<p style="color:red">Apellido debe tener x caracteres</p>';
	}

	if(!validacion\email($email)){
		$form_valido = false;
		$errores .= '<p style="color:red">Email incorrecto</p>';
	}

	if(!validacion\clave($clave)){
		$form_valido = false;
		$errores .= '<p style="color:red">La clave debe tener 6 caracteres minimo</p>';
	}

	if($clave != $clave2){
		$form_valido = false;
		$errores .= '<p style="color:red">Las claves deben ser iguales</p>';
	}

	if(!$terminos){
		$form_valido = false;
		$errores .= '<p style="color:red">Debe aceptar los términos</p>';
	}

	if($form_valido){
		header("Location: catalogo.php");
	}
}
else{ // primera vez (form vacio)
	$errores = "";
	$nombre = "";
	$apellido = "";
	$email = "";
	$checked = "";
}

//---------------------------------------------------
$dic = array(
	"{{ENCABEZADO}}" => template\encabezado(),
	"{{PIE}}" => template\pie(),
	"{{valor_nombre}}" => $nombre,
	"{{valor_apellido}}" => $apellido,
	"{{valor_email}}" => $email,
	"{{CHECKED}}" => $checked,
	"{{ERRORES}}" => $errores
);

echo template\render("templates/registro.html", $dic);