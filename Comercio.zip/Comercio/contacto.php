<?php
	$resultado = "";
	if($_SERVER["REQUEST_METHOD"]=="POST"){
		require "fn/config.inc.php";
		require "fn/email.inc.php";

		$nombre = $_POST["nombre"];
		$email = $_POST["email"];
		$mensaje = $_POST["mensaje"];
		$adjunto = $_FILES["adjunto"];
		
		$body = "Se contactó <b>$nombre</b><br>
				Y te dejó la siguiente consulta:
				<p>'$mensaje'</p><br>
				Dejó el siguiente email de contacto: $email";

		$resultado = enviar(EMAIL_DUENIO, "Dueño de Ferreteria", "Contacto:$nombre", $body, $adjunto);

		if($resultado===TRUE){
			$resultado = "Su consulta se ha enviado exitosamente.";
		}
	}
?>
<!DOCTYPE html>
<html>
	<head>
	<meta charset="utf-8">
	<title>ComercioIT | Tu E-Shop en PHP</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

	<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
	<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />	
	<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
	<script src="js/jquery.min.js"></script>
	
	</head>
	<body> 
		<!--header-->
		<?php include "encabezado.php"; ?>
		<!---->
		<div class="container">
			<section id="page">
				<div class="main"> 
					<div class="reservation_top">
						<div class=" contact_right">
							<h3>Contacto</h3>
							<div class="contact-form">
								<?=$resultado;?>
								<form action="" method="post" enctype="multipart/form-data">
									<input type="text" class="textbox" placeholder="Nombre" name="nombre">
									<input type="text" class="textbox" placeholder="E-Mail" name="email">
									<textarea placeholder="Mensaje" name="mensaje"></textarea>
									<input type="file" name="adjunto">
									<input type="submit" value="Enviar">
									<div class="clearfix"></div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</section>
			<div class="clearfix"></div>
		</div>
		<!---->
		<?php include "pie-de-pagina.php"; ?>
		<!--initiate accordion-->
		<script src="js/custom.js"></script>
	</body>
</html>