<?php
require "fn/template.inc.php";
require "fn/validacion.inc.php";
require "fn/seguridad.inc.php";
require "fn/archivo.inc.php";

//---------------------------------------------------
if($_SERVER["REQUEST_METHOD"] == "POST"){ // procesar el formulario
	$nombre = $_POST["nombre"];
	$apellido = $_POST["apellido"];
	$email = $_POST["email"];
	$clave = $_POST["pass"];
	$clave2 = $_POST["pass2"];	
	$terminos = isset($_POST["terminos"]);
	$checked = ($terminos)? "checked" : "";
	
	$captcha = $_POST["g-recaptcha-response"];


	$opciones = array (
        'https' => array (
            'method' => 'POST',
            'header'=> "Content-type: application/x-www-form-urlencoded",
            'content' => array(
					"secret" => "6Lf3pMEUAAAAAENduUECwD5ccGsoFip2EMY9SeDr",
					"response" => $captcha
				)
			)
	);
	$contexto = stream_context_create($opciones);
	$respuestaGoogle = file_get_contents("https://www.google.com/recaptcha/api/siteverify", false, $contexto);
	$respuestaGoogleJson = json_decode($respuestaGoogle);

	//var_dump($respuestaGoogleJson); exit;

	$form_valido = true;

	if(!$respuestaGoogleJson->success){
		$form_valido = false;
	}

	if(!validacion\nombre($nombre)){
		$form_valido = false;
	}

	if(!validacion\nombre($apellido)){
		$form_valido = false;
	}

	if(!validacion\email($email)){
		$form_valido = false;
	}

	if(!validacion\clave($clave)){
		$form_valido = false;
	}

	if($clave != $clave2){
		$form_valido = false;
	}

	if(!$terminos){
		$form_valido = false;		
	}

	if($form_valido){
		require "fn/config.inc.php";
		require "fn/usuario.inc.php";
		require "fn/email.inc.php";

		$token = md5($email.SALT);
		usuario\alta("$nombre $apellido", $email, md5($clave.SALT), $token);

		$link = DOMINIO."/activar.php?token=$token";
		$mensaje = "
		<h1>Hola $nombre!</h1>
		<p>Activa tu cuenta pulsando aqui:</p>
		<a style=\"background:cyan;padding:10px;\" href=\"$link\" >Activar mi cuenta</a>
		<p>Si no puedes pulsar el boton copia y pega el siguiente link en tu navegador: $link</p>
		";
		enviar($email,"$nombre $apellido","Activar cuenta en ComercioIT",$mensaje);
		header("Location: catalogo.php");
	}
	else{
		//loguear en la bitacora el problema
		$ip = seguridad\obtenerIP();
		$linea_bitacora = "Se intentó registrar sin JS con IP: $ip";
		archivo\generaLog($linea_bitacora);
		header("Location: https://www.google.com");
	}
}
else{ // primera vez (form vacio)
	$errores = "";
	$nombre = "";
	$apellido = "";
	$email = "";
	$checked = "";
}

//---------------------------------------------------
$dic = array(
	"{{ENCABEZADO}}" => template\encabezado(),
	"{{PIE}}" => template\pie(),
	"{{valor_nombre}}" => $nombre,
	"{{valor_apellido}}" => $apellido,
	"{{valor_email}}" => $email,
	"{{CHECKED}}" => $checked,
	"{{ERRORES}}" => $errores
);

echo template\render("templates/registro.html", $dic);