<?php
require "fn/session.inc.php";
session\logout();
header("Location: index.php");
