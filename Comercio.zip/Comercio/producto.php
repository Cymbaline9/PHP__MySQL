<?php
	require "fn/producto.inc.php";
	$prod = producto\obtenerPorId($_GET["id"]);
	$titulo = $prod["nombre"];
	$precio = $prod["precio"];
	$foto = $prod["foto"];
?>
<!DOCTYPE html>
<html>
	<head>
	<meta charset="utf-8">
	<title>ComercioIT | Tu E-Shop en PHP</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

	<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />	
	<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />	
	<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
	<script src="js/jquery.min.js"></script>

	</head>
	<body> 
		<!--header-->
		<?php include "encabezado.php"; ?>
		<!---->
		<div class="container">
			<section id="page">
				<div class="single_top">
					<div class="single_grid">
						<div class="grid images_3_of_2">
							<ul id="etalage">
								<li>
									<img class="etalage_thumb_image" src="<?=$foto?>" width="300" class="img-responsive" />
								</li>
							</ul>
							<div class="clearfix"></div>		
						</div>
						<div class="desc1 span_3_of_2">
							<h4><?=$titulo?></h4>
							<div class="cart-b">
								<div class="left-n ">$<?=$precio?></div>
								<a class="now-get get-cart-in" href="#">COMPRAR</a> 
								<div class="clearfix"></div>
							</div>
							<h6>100 unid. en stock</h6>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
							<div class="share">
								<h5>Compartir Producto:</h5>
								<ul class="share_nav">
									<li><a href="#"><img src="images/facebook.png" title="facebook"></a></li>
									<li><a href="#"><img src="images/twitter.png" title="Twiiter"></a></li>
									<li><a href="#"><img src="images/rss.png" title="Rss"></a></li>
									<li><a href="#"><img src="images/gpluse.png" title="Google+"></a></li>
								</ul>
							</div>
						</div>
						<div class="clearfix"></div>
					</div>
				</div>
			</section>
			<div class="clearfix"></div>
		</div>

		<!---->
		<?php include "pie-de-pagina.php"; ?>
		<!--initiate accordion-->
		<script src="js/custom.js"></script>
	</body>
</html>