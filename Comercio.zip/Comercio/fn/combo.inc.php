<?php
namespace combo{
    require_once "config.inc.php";
    use \PDO;

    // Devuelve <option> de cada categorias
    function categorias($elegido){
        $cnx = nuevaConexion();
        $query = "
            SELECT cod_categoria id, nombre_categoria name
            FROM categorias
            ORDER BY 2 ASC
        ";
        $statement = $cnx->prepare($query);
        $statement->execute();

        $opt = "";
        
        while($fila = $statement->fetch(PDO::FETCH_ASSOC)){
            $selected = ($fila["id"]==$elegido)? "selected" : "";
            $opt .= "<option value=\"{$fila["id"]}\" $selected >
                        {$fila["name"]}
                     </option>";
        }
        return $opt;
    }
    function marcas($elegido){
        $cnx = nuevaConexion();
        $query = "
            SELECT cod_marca id, nombre_marca name
            FROM marcas
            ORDER BY 2 ASC
        ";
        $statement = $cnx->prepare($query);
        $statement->execute();

        $opt = "";
        while($fila = $statement->fetch(PDO::FETCH_ASSOC)){
            $selected = ($fila["id"]==$elegido)? "selected" : "";
            $opt .= "<option value=\"{$fila["id"]}\" $selected >
                        {$fila["name"]}
                     </option>";
        }
        return $opt;
    }
    function nuevaConexion(){
        //"mysql:dbname=limon;host=localhost;port=3307"
        $conexion = new PDO("mysql:host=".HOST.";dbname=" . NAME, USER, PASS);
        return $conexion;
    }

}