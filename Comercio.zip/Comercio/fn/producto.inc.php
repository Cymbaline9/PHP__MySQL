<?php
namespace producto{
    require_once "config.inc.php";
    require_once "template.inc.php";
    use \PDO;   //use \PDO as PDO;
    use \template;

    // devolver todos productos como filas de una tabla html
    function obtenerTRs($pagina, $orden, $sentido, $filtro_nombre, $filtro_marca){
        $cnx = nuevaConexion();
        $query = "SELECT                         
                        C.nombre_categoria as '{{CATEGORIA}}',
                        P.nombre as '{{NOMBRE}}',
                        P.precio as '{{PRECIO}}',
                        M.nombre_marca as '{{MARCA}}',
                        P.foto as '{{FOTO}}',
                        P.id_producto '{{ID}}'
                    FROM productos P
                    LEFT JOIN categorias C ON(C.cod_categoria = P.cod_categoria)
                    LEFT JOIN marcas M ON(M.cod_marca = P.cod_marca)
                    WHERE 1=1
                    AND P.nombre LIKE '%$filtro_nombre%'
                    AND M.nombre_marca LIKE '%$filtro_marca%'   
                    ORDER BY $orden $sentido";
        $statement = $cnx->prepare($query);
        $statement->execute();
        
        $cant_productos = $statement->rowCount();
        $cant_reg_mostrar = 10;
        $cant_paginas = ceil($cant_productos / $cant_reg_mostrar);

        $aux = array();
        for($i=1; $i<=$cant_paginas; $i++){
            array_push($aux, "<a onclick=\"enviarPagina($i)\" href=\"#\">$i</a>");
        }
        $links = implode(" | ", $aux);        
        $salto = ($pagina - 1) * $cant_reg_mostrar;
        $query .= " LIMIT $cant_reg_mostrar OFFSET $salto ";
        $statement = $cnx->prepare($query);
        $statement->execute();

        $trs = "";
        $template = template\cargarTemplate("parciales/fila_producto.html");
        while($prod = $statement->fetch(PDO::FETCH_ASSOC)){
            $trs .= template\traducir($template, $prod);
        }

        $cnx = NULL;
        return array($trs, $links);
    }
    function obtenerArray(){
        $cnx = nuevaConexion();
        $query = "SELECT                         
                        C.nombre_categoria as 'CATEGORIA',
                        P.nombre as 'NOMBRE',
                        P.precio as 'PRECIO',
                        M.nombre_marca as 'MARCA',
                        P.foto as 'FOTO',
                        P.id_producto 'ID'
                    FROM productos P
                    LEFT JOIN categorias C ON(C.cod_categoria = P.cod_categoria)
                    LEFT JOIN marcas M ON(M.cod_marca = P.cod_marca)
                  ORDER BY 2 ASC
        ";
        $statement = $cnx->prepare($query);
        $statement->execute();
        return $statement->fetchAll(PDO::FETCH_ASSOC);
    }
    function obtenerPorId($id){
        $cnx = nuevaConexion();
        $query = "SELECT * FROM productos WHERE id_producto = $id LIMIT 1";
        $statement = $cnx->prepare($query);
        $statement->execute();
        return $statement->fetch(PDO::FETCH_ASSOC);
    }
    function crear($nombre, $categoria, $precio, $marca, $rutaFoto){        
        $cnx = nuevaConexion();
        $query = "
            INSERT INTO productos
            (nombre, cod_categoria, precio, cod_marca, foto ,stock)
            VALUES
            ('$nombre', $categoria, $precio, $marca, '$rutaFoto' ,100)
        ";
        $res = $cnx->exec($query);
        if($res){
            $query = "SELECT id_producto 
                      FROM productos 
                      ORDER BY id_producto DESC 
                      LIMIT 1";
            $statement = $cnx->prepare($query);     
            $statement->execute();
            $fila = $statement->fetch(PDO::FETCH_ASSOC);
            $res = $fila["id_producto"];
        }

        $cnx = NULL;                   
        return $res;
    }
    function modificar($id, $nombre, $categoria, $precio, $marca, $rutaFoto){
        $cnx = nuevaConexion();
        $setFoto = ($rutaFoto)? " foto = '$rutaFoto', " : "";
        $query = "UPDATE productos
                  SET nombre = '$nombre',
                      $setFoto
                      cod_categoria = $categoria,
                      precio = $precio,
                      cod_marca = $marca
                  WHERE id_producto = $id
        ";
        return $cnx->exec($query);
    }
    function borrar($id){
        $cnx = nuevaConexion();
        return $cnx->exec("DELETE FROM productos WHERE id_producto = $id ");
    }
    function nuevaConexion(){
        $conexion = new PDO("mysql:host=".HOST.";dbname=" . NAME, USER, PASS);
        return $conexion;
    }
}