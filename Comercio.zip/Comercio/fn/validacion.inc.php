<?php
// VALIDACION.INC.PHP
namespace validacion{
	function nombre($n){
		if(strlen($n) >= 3){
			return true;
		}
		return false;
	}

	function email($e){
		// https://regex101.com/
		$patron = "/^[\._a-z0-9-]+@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/i";
		return preg_match($patron, $e);
	}

	function clave($clave){
		if(strlen($clave)>=6 && preg_match("/^[a-z0-9]+$/", $clave)){
			return true;
		}
		return false;
	}
}
