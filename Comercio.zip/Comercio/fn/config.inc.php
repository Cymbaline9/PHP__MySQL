<?php

# Base de datos
define("HOST", "localhost");
define("USER", "root");
define("PASS", "");
define("NAME", "limon");

# carpetas
define("PHOTOS", "fotos/rdiaz");

# Dominio utilizado
//define("DOMINIO", "https://comercioit2019.000webhostapp.com");
define("SALT", "SaltPHPCurso");

# Cuenta de email
define("SERVIDOR_EMAIL", "smtp.gmail.com");
define("PUERTO_EMAIL", 587);
define("USUARIO_EMAIL", "docentewebit@gmail.com");
define("CLAVE_EMAIL", "it2018webphp");
define("NIVEL_ERROR", 2); // poner en cero en producción
define("FROM_EMAIL", "administrador@misitio.com");
define("NAME_EMAIL", "Administrador");
define("EMAIL_DUENIO","mensajes.roberto@gmail.com");
