<?php
namespace upload{
    require_once "fn/config.inc.php";
    require_once "fn/archivo.inc.php";
    use \archivo;

    function comprobarArchivo($archivo){
        if($archivo["error"]==0 && $archivo["size"]>0){
            return true;
        }
        return false;
    }
    function subirArchivo($archivo){
        //move_uploaded_file("ruta/al/origen.tmp", "ruta/al/destino.jpg");
        if(comprobarArchivo($archivo)){
            archivo\crearDirectorio(PHOTOS);
            $destino = PHOTOS . "/" . date("Ymdhis") . "_". $archivo["name"];
            move_uploaded_file($archivo["tmp_name"], $destino);
            return $destino;
        }
        return "";
    }
}