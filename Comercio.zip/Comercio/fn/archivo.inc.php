<?php
namespace archivo{

    function generaLog($accion){
        //Definimos la hora de la accion
        $hora = str_pad(date("H:i:s"), 10, " "); //  hh:mm:ss
        $accion = str_pad($accion, 50, " ");
        $cadena = $hora.$accion;
        //Creamos dinamicamente el nombre del archivo por dia
        $pre = "CONSOLE-log-";
        $date = date("ymd"); //aammdd
        $fileName = $pre.$date;
        //Creamos el directorio de logs
        $ruta = "logs";
    
        nuevaCarpeta($ruta);
    
        $f = fopen("{$ruta}/{$fileName}.txt", "a");
             fputs($f, $cadena."\r\n");
    
        fclose($f);   
    }

    function nuevaCarpeta($nombre){
        if (!is_dir($nombre)) { // si la carpeta no existe
            mkdir($nombre, 0775); //la creo dando todos los permisos necesarios para guardar imagenes en ella
            chmod($nombre, 0775);
        }
    }

    function crearDirectorio($ruta){
        $carpetas = explode('/', $ruta);
        $padre = "";
        foreach($carpetas as $folder){
            nuevaCarpeta($padre.$folder);
            $padre .= $folder.'/';            
        }
    }
    /*
    $ruta = "images/icons/colors"
    1   ""."images"
    2   "images/"."icons"
    3   "images/icons/"."colors"
    */
}