<?php
require_once "fn/session.inc.php";
function menu(){
    $menu = array();
    array_push($menu, '<li><a href="index.php">Inicio</a></li>');

    $usr = session\leer("usuario");
    if($usr){ // logueado?
        if($usr["id_perfil"]==1){ // soy admin?
            array_push($menu, '<li><a href="listado_productos.php">LISTADO</a></li>');    
        }        
        array_push($menu, '<li><a href="logout.php">Salir</a></li>');
    }
    else{
        array_push($menu, '<li><a href="ingreso.php">Ingresar</a></li>');
        array_push($menu, '<li><a href="registro.php">Registrarse</a></li>');
    } 

    return implode("&nbsp;|&nbsp;", $menu);
}