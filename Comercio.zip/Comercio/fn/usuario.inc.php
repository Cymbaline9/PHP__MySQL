<?php
namespace usuario{
    require_once "fn/config.inc.php";
    use \PDO;
    function alta($nombre, $email, $clave, $token){
        $cnx = nuevaConexion();
        return $cnx->exec("
            INSERT INTO usuarios
            (nombre, email, clave, activo, token, id_perfil)
            VALUES
            ('$nombre', '$email', '$clave', 0, '$token', 0)
        ");
    }
    function activar($token){
        $cnx = nuevaConexion();
        $resp = $cnx->exec("
            UPDATE usuarios
            SET activo = 1
            WHERE token = '$token'
        ");
        if($resp){
            return "Usuario activado";
        }
        return "No se pudo activar, vuelva a registrarse";
    }
    function login($email, $clave){
        $cnx = nuevaConexion();
        $hash = md5($clave.SALT);
        $query = "SELECT * FROM usuarios 
                  WHERE email = '$email' 
                    AND clave = '$hash'
                    AND activo = 1
        ";        
        $statement = $cnx->prepare($query);
        $statement->execute();
        //return $statement->rowCount();
        return $statement->fetch(PDO::FETCH_ASSOC);
    }
   
    function nuevaConexion(){
        $conexion = new PDO("mysql:host=".HOST.";dbname=" . NAME, USER, PASS);
        return $conexion;
    }
}