<?php
// TEMPLATE.INC.PHP
namespace template{	

	function cargarTemplate($url){
		return file_get_contents($url);
	}
	function traducir($template, $diccionario){
		foreach ($diccionario as $key => $value) {
			$template = str_replace($key, $value, $template);
		}
		return $template;
	}

	function render($url, $diccionario){
		$template = cargarTemplate($url);		
		return traducir($template, $diccionario);
	}

	function encabezado(){
		require_once "fn/menu.inc.php";		
		return render("encabezado.php", array("{{MENU}}" => menu() ));		
	}

	function pie(){
		return file_get_contents("pie-de-pagina.php");
	}


}
