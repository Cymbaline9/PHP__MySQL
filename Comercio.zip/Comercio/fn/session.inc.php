<?php
namespace session{
    function setear($clave, $valor){
        session_start();
        $_SESSION[$clave] = $valor;
        session_write_close();
    }
    function leer($clave){
        session_start();        
        $valor = (isset($_SESSION[$clave]))? $_SESSION[$clave] : false;
        session_write_close();
        return $valor;
    }
    function logout(){
        session_start(); 
        $_SESSION["usuario"] = NULL;
        session_destroy();
        
        session_write_close();
    }
}