<?php
	/*require "fn/session.inc.php";
	var_dump(session\leer("usuario"));*/

?>
<!DOCTYPE html>
<html>
	<head>
	<meta charset="utf-8">
	<title>ComercioIT | Tu E-Shop en PHP</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

	<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
	<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />	
	<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
	<script src="js/jquery.min.js"></script>
	
	<script type="text/javascript">
		function enviarPagina(param){
            document.querySelector("#pagina").value = param;
            document.querySelector("#formulario").submit();
        }
        function enviarOrden(param){
            document.querySelector("#orden").value = param;
			
			var anterior_valor = document.querySelector("#sentido").value;
			var sentido = (anterior_valor!="DESC")? "DESC" : "ASC"
			// operador ternario: es un if de una linea.
			// si el valor no es DESC, en sentido se guarda "DESC", sino, se guarda "ASC".
			document.querySelector("#sentido").value = sentido;
            document.querySelector("#formulario").submit();
        }
	</script>
	</head>
	<body> 
		<!--header-->
		<?php
			require "fn/template.inc.php";
			echo template\encabezado();
		?>
		<!---->
		<div class="container">

			<h2 style="text-align: center;">0 visitantes</h2>

			<form id="formulario" action="" method="GET" style="display:none;" >
				<input type="hidden" id="pagina" name="pagina" value="" />
				<input type="hidden" id="orden" name="orden" value="" />
				<input type="hidden" id="sentido" name="sentido" value="" />
			</form>

			<section id="page">

				<!-- ULTIMOS PRODUCTOS -->
				<div class="shoes-grid">
					<div class="products">
						<h5 class="latest-product">ULTIMOS PRODUCTOS</h5>	
						<a class="view-all" href="productos.php">VER TODOS<span></span></a>
					</div>
					<div class="product-left">
						<!-- Producto #1 -->
						<div class="col-sm-4 col-md-4 chain-grid">
							<a href="producto.php"><img class="img-responsive chain" src="images/productos/P004.jpg" alt=" " /></a>
							<span class="star"></span>
							<div class="grid-chain-bottom">
								<h6><a href="producto.php">Lorem ipsum dolor #1</a></h6>
								<div class="star-price">
									<div class="dolor-grid"> 
										<span class="actual">300$</span>
									</div>
									<a class="now-get get-cart" href="#">VER MÁS</a> 
									<div class="clearfix"></div>
								</div>
							</div>
						</div>
						<!-- Producto #2 -->
						<div class="col-sm-4 col-md-4 chain-grid">
							<a href="producto.php"><img class="img-responsive chain" src="images/productos/P005.jpg" alt=" " /></a>
							<span class="star"></span>
							<div class="grid-chain-bottom">
								<h6><a href="producto.php">Lorem ipsum dolor #2</a></h6>
								<div class="star-price">
									<div class="dolor-grid"> 
										<span class="actual">300$</span>
									</div>
									<a class="now-get get-cart" href="#">VER MÁS</a> 
									<div class="clearfix"></div>
								</div>
							</div>
						</div>
						<!-- Producto #3 -->
						<div class="col-sm-4 col-md-4 chain-grid grid-top-chain">
							<a href="producto.php"><img class="img-responsive chain" src="images/productos/P006.jpg" alt=" " /></a>
							<span class="star"></span>
							<div class="grid-chain-bottom">
								<h6><a href="producto.php">Lorem ipsum dolor #3</a></h6>
								<div class="star-price">
									<div class="dolor-grid"> 
										<span class="actual">300$</span>
									</div>
									<a class="now-get get-cart" href="#">VER MÁS</a> 
									<div class="clearfix"></div>
								</div>
							</div>
						</div>
						<div class="clearfix"></div>
					</div>
					<div class="clearfix"> </div>
				</div>

				<!-- PRODUCTOS DESTACADOS -->
				<div class="shoes-grid">
					<div class="products">
						<h5 class="latest-product">PRODUCTOS DESTACADOS</h5>
					</div>
					<div class="product-left">
						
						<!-- Producto #1 -->
						<div class="col-sm-4 col-md-4 chain-grid " style="margin-bottom: 10px;">
							<a href="producto.php">
								<img class="img-responsive chain" src="" alt="" style="width:300px;height:300px" />
							</a>
							<div class="grid-chain-bottom">
								<h6 class="truncate"><a href="producto.php">producto</a></h6>
								<div class="star-price">
									<div class="dolor-grid"> 
										<span class="actual">$ 0</span>
									</div>
									<a class="now-get get-cart" href="producto.php">VER MÁS</a> 
									<div class="clearfix"></div>
								</div>
							</div>
						</div>

						<div class="clearfix"></div>
					</div>
					<div class="clearfix"> </div>
					<div class="products">
						<h5 class="latest-product">1 2 3 ...</h5>
					</div>					
				</div>

			</section>

		</div>
		<!--Pie de pagina-->
		<?php
			include("pie-de-pagina.php");
		?>
		<!---->
		<script src="js/custom.js"></script>
	</body>
</html>