<?php
require "fn/template.inc.php";
require "fn/producto.inc.php";

$error = (isset($_GET["error"]) && $_GET["error"])? $_GET["error"] : '';

$pagina = (isset($_GET["pagina"]) && $_GET["pagina"])? $_GET["pagina"] : 1;
$orden = (isset($_GET["orden"]) && $_GET["orden"])? $_GET["orden"] : 2;
$sentido = (isset($_GET["sentido"]) && $_GET["sentido"])? $_GET["sentido"] : 'ASC';
$producto = (isset($_GET["producto"]) && $_GET["producto"])? $_GET["producto"] : '';
$marca = (isset($_GET["marca"]) && $_GET["marca"])? $_GET["marca"] : '';

$res = producto\obtenerTRs($pagina, $orden, $sentido, $producto, $marca);
$filas = $res[0];
$paginador = $res[1];

//-----------------------------
$dic = array(
	"{{ENCABEZADO}}" => template\encabezado(),
	"{{PIE}}" => template\pie(),
	"{{FILAS}}" => $filas,
	"{{PAGINADOR}}" => $paginador,
	"{{FILTRO_NOMBRE}}" => $producto,
	"{{FILTRO_MARCA}}" => $marca,
	"{{SENTIDO}}" => $sentido,
	"{{PAGINA}}" => $pagina,
	"{{ORDEN}}" => $orden,
	"{{ERROR}}" => $error,
);

echo template\render("templates/listado.html", $dic);