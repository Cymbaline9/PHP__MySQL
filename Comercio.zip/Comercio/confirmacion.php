<?php
	
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Activación</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

	<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
	<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />	
	<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
	<script src="js/jquery.min.js"></script>
	
</head>
<body>
	<!--header-->
	<?php include "encabezado.php"; ?>
	<!---->

	<p>
		Revise su email <b>email@ejemplo</b> para activar su cuenta.	
	</p>
	<a href="ingreso.php">Ingresar</a>

	<!--footer-->
	<?php include "pie-de-pagina.php"; ?>
	<!---->
</body>
</html>	