<?php
    require "fn/producto.inc.php";

    producto\borrar($_GET["id"]);
    $mensaje = "El producto fue borrado exitosamente";

    header("Location: listado_productos.php?error={$mensaje}");
